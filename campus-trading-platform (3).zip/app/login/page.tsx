"use client"

import type React from "react"

import { useState } from "react"
import { Eye, EyeOff, BadgeIcon as IdCard, Lock } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Navigation from "../components/navigation"
import Footer from "../components/footer"
import { useUser } from "../contexts/user-context"

export default function LoginPage() {
  const router = useRouter()
  const { login } = useUser()

  const [formData, setFormData] = useState({
    userId: "",
    password: "",
    rememberMe: false,
  })

  const [errors, setErrors] = useState({
    userId: "",
    password: "",
    general: "",
  })

  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))

    // Clear error when user types
    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }))
    }
  }

  // Validate form
  const validateForm = () => {
    let isValid = true
    const newErrors = {
      userId: "",
      password: "",
      general: "",
    }

    // Validate user ID
    if (!formData.userId) {
      newErrors.userId = "请输入用户ID"
      isValid = false
    }

    // Validate password
    if (!formData.password) {
      newErrors.password = "请输入密码"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsLoading(true)

    try {
      const success = await login(formData.userId, formData.password)

      if (success) {
        router.push("/")
      } else {
        setErrors((prev) => ({
          ...prev,
          general: "登录失败，用户ID或密码错误",
        }))
      }
    } catch (error) {
      setErrors((prev) => ({
        ...prev,
        general: "登录失败，请稍后再试",
      }))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Navigation />

      <main className="flex-grow container mx-auto px-4 py-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 sm:p-8">
              <h1 className="text-2xl font-bold text-gray-800 mb-6 text-center">登录账号</h1>

              {errors.general && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
                  {errors.general}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="space-y-5">
                  {/* User ID */}
                  <div>
                    <label htmlFor="userId" className="block text-sm font-medium text-gray-700 mb-1">
                      用户ID
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        id="userId"
                        name="userId"
                        value={formData.userId}
                        onChange={handleChange}
                        className={`w-full pl-10 pr-4 py-2 border ${
                          errors.userId ? "border-red-500" : "border-gray-300"
                        } rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent`}
                        placeholder="请输入用户ID (例如: user123)"
                      />
                      <IdCard className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                    </div>
                    {errors.userId && <p className="mt-1 text-sm text-red-600">{errors.userId}</p>}
                  </div>

                  {/* Password */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                        密码
                      </label>
                      <Link href="/forgot-password" className="text-sm text-primary hover:underline">
                        忘记密码?
                      </Link>
                    </div>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        className={`w-full pl-10 pr-10 py-2 border ${
                          errors.password ? "border-red-500" : "border-gray-300"
                        } rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent`}
                        placeholder="请输入密码 (例如: password123)"
                      />
                      <Lock className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                      <button
                        type="button"
                        className="absolute right-3 top-2.5 text-gray-400"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                    {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password}</p>}
                  </div>

                  {/* Remember Me */}
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="rememberMe"
                      name="rememberMe"
                      checked={formData.rememberMe}
                      onChange={handleChange}
                      className="h-4 w-4 text-primary border-gray-300 rounded focus:ring-primary"
                    />
                    <label htmlFor="rememberMe" className="ml-2 block text-sm text-gray-700">
                      记住我
                    </label>
                  </div>

                  {/* Login Button */}
                  <div>
                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isLoading ? "登录中..." : "登录"}
                    </button>
                  </div>

                  {/* Register Link */}
                  <div className="text-center mt-4">
                    <p className="text-sm text-gray-600">
                      还没有账号?{" "}
                      <Link href="/register" className="text-primary hover:underline">
                        立即注册
                      </Link>
                    </p>
                  </div>
                </div>
              </form>

              {/* 测试账号信息 */}
              <div className="mt-8 p-4 bg-gray-50 rounded-md">
                <h3 className="text-sm font-medium text-gray-700 mb-2">测试账号:</h3>
                <div className="text-xs text-gray-600 space-y-1">
                  <p>用户ID: user123, 密码: password123</p>
                  <p>用户ID: user456, 密码: password456</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
