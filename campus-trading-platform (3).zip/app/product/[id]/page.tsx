"use client"

import Link from "next/link"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation"
import { MapPin, MessageCircle, ShoppingCart } from "lucide-react"
import Navigation from "@/app/components/navigation"
import Footer from "@/app/components/footer"
import { useUser } from "@/app/contexts/user-context"
import { getImageUrl } from "@/app/utils/image-utils"

// 初始商品数据
const initialProducts = [
  {
    id: "1",
    title: "二手笔记本电脑",
    price: 2500,
    location: "东区宿舍",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=500&auto=format&fit=crop",
    category: "电子产品",
    description: "戴尔笔记本电脑，i5处理器，8GB内存，256GB固态硬盘，使用了2年，成色9成新，无明显磨损。",
    seller: {
      id: "user123",
      name: "张同学",
      avatar: "",
    },
  },
  {
    id: "2",
    title: "自行车",
    price: 350,
    location: "西区宿舍",
    image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?q=80&w=500&auto=format&fit=crop",
    category: "自行车",
    description: "捷安特自行车，使用一年，外观良好，轮胎完好，适合校园通勤。",
    seller: {
      id: "user456",
      name: "李同学",
      avatar: "",
    },
  },
  {
    id: "3",
    title: "考研教材全套",
    price: 120,
    location: "图书馆",
    image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=500&auto=format&fit=crop",
    category: "书籍教材",
    description: "包含数学、英语、政治全套教材和辅导资料，有少量笔记，保存完好。",
    seller: {
      id: "user789",
      name: "王同学",
      avatar: "",
    },
  },
  {
    id: "4",
    title: "篮球",
    price: 80,
    location: "体育馆",
    image: "https://images.unsplash.com/photo-1608245449230-4ac19066d2d0?q=80&w=500&auto=format&fit=crop",
    category: "运动器材",
    description: "斯伯丁篮球，使用3个月，手感良好，适合室内外使用。",
    seller: {
      id: "user101",
      name: "赵同学",
      avatar: "",
    },
  },
  {
    id: "5",
    title: "吉他",
    price: 450,
    location: "音乐学院",
    image: "https://images.unsplash.com/photo-1525201548942-d8732f6617a0?q=80&w=500&auto=format&fit=crop",
    category: "乐器",
    description: "雅马哈吉他，F310型号，木吉他，音色清脆，适合初学者。",
    seller: {
      id: "user121",
      name: "钱同学",
      avatar: "",
    },
  },
]

export default function ProductDetail() {
  const params = useParams()
  const router = useRouter()
  const { addToCart, cartItems } = useUser()
  const [showChatModal, setShowChatModal] = useState(false)
  const [message, setMessage] = useState("")
  const [addedToCart, setAddedToCart] = useState(false)
  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  // 加载商品数据
  useEffect(() => {
    const productId = params.id

    // 首先检查是否是初始商品
    const initialProduct = initialProducts.find((p) => p.id === productId)
    if (initialProduct) {
      setProduct(initialProduct)
      setLoading(false)
      return
    }

    // 然后检查本地存储中的商品
    try {
      const storedProducts = localStorage.getItem("publishedProducts")
      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts)
        const storedProduct = parsedProducts.find((p: any) => p.id === Number(productId))

        if (storedProduct) {
          setProduct(storedProduct)
          setLoading(false)
          return
        }
      }
    } catch (error) {
      console.error("Failed to parse stored products:", error)
    }

    // 如果找不到商品，使用第一个初始商品作为默认值
    setProduct(initialProducts[0])
    setLoading(false)
  }, [params.id])

  // 检查商品是否已在购物车中
  useEffect(() => {
    if (product) {
      const isInCart = cartItems.some((item) => item.id === Number(product.id))
      setAddedToCart(isInCart)
    }
  }, [cartItems, product])

  // 处理添加到购物车
  const handleAddToCart = () => {
    if (!addedToCart && product) {
      addToCart({
        id: Number(product.id),
        title: product.title,
        price: product.price,
        image: product.images && product.images.length > 0 ? product.images[0] : product.image,
        seller: product.seller.name,
      })
      setAddedToCart(true)
    }
  }

  // 处理发送消息
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    alert(`消息已发送: ${message}`)
    setMessage("")
    setShowChatModal(false)
  }

  // 如果正在加载，显示加载状态
  if (loading) {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50">
        <Navigation />
        <main className="flex-grow container mx-auto px-4 py-8 flex items-center justify-center">
          <p>加载商品信息...</p>
        </main>
        <Footer />
      </div>
    )
  }

  // 如果找不到商品，显示错误信息
  if (!product) {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50">
        <Navigation />
        <main className="flex-grow container mx-auto px-4 py-8 flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <h2 className="text-xl font-semibold text-gray-700 mb-2">商品不存在</h2>
            <p className="text-gray-500 mb-6">抱歉，您查找的商品不存在或已被删除</p>
            <Link href="/" className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 inline-block">
              返回首页
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Navigation />

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6">
            {/* Product Image */}
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
              <Image
                src={
                  product.images && product.images.length > 0
                    ? product.images[0]
                    : product.image || getImageUrl("", "product", product.title, product.category)
                }
                alt={product.title}
                fill
                className="object-cover"
              />
            </div>

            {/* Product Details */}
            <div className="flex flex-col">
              <h1 className="text-2xl font-bold text-gray-800 mb-2">{product.title}</h1>
              <p className="text-primary font-bold text-3xl mb-4">¥{product.price}</p>

              <div className="flex items-center mb-4 text-gray-500">
                <MapPin className="h-5 w-5 mr-2" />
                <span>{product.location}</span>
              </div>

              <div className="flex items-center mb-6">
                <Image
                  src={getImageUrl(product.seller.avatar, "avatar") || "/placeholder.svg"}
                  alt={product.seller.name}
                  width={40}
                  height={40}
                  className="rounded-full mr-2"
                />
                <span className="font-medium">{product.seller.name}</span>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <h2 className="font-semibold mb-2">商品描述</h2>
                <p className="text-gray-700">{product.description}</p>
              </div>

              <div className="mt-auto flex space-x-4">
                <button
                  onClick={() => setShowChatModal(true)}
                  className="flex items-center justify-center px-4 py-2 border border-primary text-primary rounded-md hover:bg-primary hover:text-white transition-colors w-1/2"
                >
                  <MessageCircle className="h-5 w-5 mr-2" />
                  联系卖家
                </button>
                <button
                  onClick={handleAddToCart}
                  disabled={addedToCart}
                  className={`flex items-center justify-center px-4 py-2 rounded-md transition-colors w-1/2 ${
                    addedToCart ? "bg-green-500 text-white" : "bg-primary text-white hover:bg-primary/90"
                  }`}
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  {addedToCart ? "已加入购物车" : "加入购物车"}
                </button>
              </div>
            </div>
          </div>

          {/* Additional Images */}
          {product.images && product.images.length > 1 && (
            <div className="p-6 border-t border-gray-200">
              <h2 className="font-semibold mb-4">更多图片</h2>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
                {product.images.slice(1).map((image: string, index: number) => (
                  <div key={index} className="relative h-24 rounded-md overflow-hidden">
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${product.title} - 图片 ${index + 2}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Chat Modal */}
      {showChatModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-lg w-full max-w-md">
            <div className="flex justify-between items-center border-b p-4">
              <h2 className="text-lg font-semibold">联系 {product.seller.name}</h2>
              <button onClick={() => setShowChatModal(false)} className="text-gray-500 hover:text-gray-700">
                ×
              </button>
            </div>
            <div className="p-4">
              <div className="mb-4">
                <p className="text-sm text-gray-500 mb-2">关于商品: {product.title}</p>
                <div className="bg-gray-100 p-3 rounded-lg">
                  <p className="text-sm">您好！我对您的商品感兴趣，可以详细了解一下吗？</p>
                </div>
              </div>
              <form onSubmit={handleSendMessage}>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full border border-gray-300 rounded-md p-2 mb-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  rows={3}
                  placeholder="输入您想问的问题..."
                  required
                ></textarea>
                <div className="flex justify-end">
                  <button type="submit" className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90">
                    发送消息
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  )
}
