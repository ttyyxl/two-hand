"use client"

import Image from "next/image"
import Link from "next/link"
import { Trash2, ShoppingBag } from "lucide-react"
import Navigation from "../components/navigation"
import Footer from "../components/footer"
import { useUser } from "../contexts/user-context"
import { getImageUrl } from "../utils/image-utils"

export default function CartPage() {
  const { cartItems, removeFromCart } = useUser()

  // Calculate total price
  const totalPrice = cartItems.reduce((sum, item) => sum + item.price, 0)

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Navigation />

      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">购物车</h1>

        {cartItems.length > 0 ? (
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="divide-y divide-gray-200">
              {cartItems.map((item) => (
                <div key={item.id} className="p-4 flex items-center">
                  <div className="relative h-20 w-20 flex-shrink-0">
                    <Image
                      src={getImageUrl(item.image, "product") || "/placeholder.svg"}
                      alt={item.title}
                      fill
                      className="object-cover rounded-md"
                    />
                  </div>
                  <div className="ml-4 flex-grow">
                    <Link href={`/product/${item.id}`} className="text-lg font-medium text-gray-800 hover:text-primary">
                      {item.title}
                    </Link>
                    <p className="text-gray-500 text-sm">卖家: {item.seller}</p>
                  </div>
                  <div className="text-primary font-bold text-lg mr-4">¥{item.price}</div>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="text-red-500 hover:text-red-700"
                    aria-label="移除商品"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="p-4 bg-gray-50 flex justify-between items-center">
              <div>
                <p className="text-gray-600">共 {cartItems.length} 件商品</p>
                <p className="text-xl font-bold">总计: ¥{totalPrice}</p>
              </div>
              <button className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 focus:outline-none">
                结算
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <ShoppingBag className="h-16 w-16 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">购物车为空</h2>
            <p className="text-gray-500 mb-6">您的购物车中还没有商品</p>
            <Link href="/" className="px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 inline-block">
              浏览商品
            </Link>
          </div>
        )}
      </main>

      <Footer />
    </div>
  )
}
