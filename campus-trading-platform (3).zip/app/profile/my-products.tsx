"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Edit, Trash2, Eye, EyeOff } from "lucide-react"
import { useUser } from "../contexts/user-context"
import { getImageUrl } from "../utils/image-utils"

export default function MyProducts() {
  const { userProducts, updateUserProduct, removeUserProduct } = useUser()
  const [activeTab, setActiveTab] = useState("all") // all, active, sold, hidden
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  // 从本地存储加载发布的商品
  useEffect(() => {
    setLoading(true)
    try {
      const storedProducts = localStorage.getItem("publishedProducts")
      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts)
        if (Array.isArray(parsedProducts)) {
          setProducts(parsedProducts)
        } else {
          setProducts([])
        }
      } else {
        setProducts([])
      }
    } catch (error) {
      console.error("Failed to parse stored products:", error)
      setProducts([])
    } finally {
      setLoading(false)
    }
  }, [])

  // 合并用户上下文中的商品和本地存储的商品
  const allProducts = [...userProducts, ...products]

  // Filter products based on active tab
  const filteredProducts =
    activeTab === "all" ? allProducts : allProducts.filter((product) => product.status === activeTab)

  // Toggle product visibility
  const toggleVisibility = (id: number) => {
    // 检查是否是用户上下文中的商品
    const userProduct = userProducts.find((p) => p.id === id)
    if (userProduct) {
      updateUserProduct({
        ...userProduct,
        status: userProduct.status === "hidden" ? "active" : "hidden",
      })
      return
    }

    // 如果是本地存储的商品，更新本地存储
    try {
      const storedProducts = localStorage.getItem("publishedProducts")
      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts)
        const updatedProducts = parsedProducts.map((p: any) => {
          if (p.id === id) {
            return {
              ...p,
              status: p.status === "hidden" ? "active" : "hidden",
            }
          }
          return p
        })

        localStorage.setItem("publishedProducts", JSON.stringify(updatedProducts))
        setProducts(updatedProducts)
      }
    } catch (error) {
      console.error("Failed to update product visibility:", error)
      alert("更新商品状态失败，请重试")
    }
  }

  // Delete product
  const deleteProduct = (id: number) => {
    if (!confirm("确定要删除这个商品吗？")) {
      return
    }

    // 检查是否是用户上下文中的商品
    const userProduct = userProducts.find((p) => p.id === id)
    if (userProduct) {
      removeUserProduct(id)
      return
    }

    // 如果是本地存储的商品，从本地存储中删除
    try {
      const storedProducts = localStorage.getItem("publishedProducts")
      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts)
        const updatedProducts = parsedProducts.filter((p: any) => p.id !== id)

        localStorage.setItem("publishedProducts", JSON.stringify(updatedProducts))
        setProducts(updatedProducts)
      }
    } catch (error) {
      console.error("Failed to delete product:", error)
      alert("删除商品失败，请重试")
    }
  }

  return (
    <div className="mt-8">
      <h2 className="text-xl font-bold text-gray-800 mb-4">我发布的商品</h2>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-4">
        <button
          onClick={() => setActiveTab("all")}
          className={`px-4 py-2 font-medium text-sm ${
            activeTab === "all" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          全部
        </button>
        <button
          onClick={() => setActiveTab("active")}
          className={`px-4 py-2 font-medium text-sm ${
            activeTab === "active" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          在售中
        </button>
        <button
          onClick={() => setActiveTab("sold")}
          className={`px-4 py-2 font-medium text-sm ${
            activeTab === "sold" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          已售出
        </button>
        <button
          onClick={() => setActiveTab("hidden")}
          className={`px-4 py-2 font-medium text-sm ${
            activeTab === "hidden" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          已隐藏
        </button>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="text-center py-8">
          <p className="text-gray-500">加载商品中...</p>
        </div>
      )}

      {/* Products List */}
      {!loading && (
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {filteredProducts.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {filteredProducts.map((product) => (
                <div key={product.id} className="p-4 flex items-center">
                  <div className="relative h-16 w-16 flex-shrink-0">
                    <Image
                      src={
                        product.images && product.images.length > 0
                          ? product.images[0]
                          : getImageUrl("", "product", product.title, product.category)
                      }
                      alt={product.title}
                      fill
                      className="object-cover rounded-md"
                    />
                  </div>
                  <div className="ml-4 flex-grow">
                    <Link href={`/product/${product.id}`} className="font-medium text-gray-800 hover:text-primary">
                      {product.title}
                    </Link>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <span className="mr-4">¥{product.price}</span>
                      <span className="mr-4">浏览 {product.views || 0} 次</span>
                      <span>发布于 {product.createdAt || "未知日期"}</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span
                      className={`px-2 py-1 text-xs rounded-full mr-3 ${
                        product.status === "active"
                          ? "bg-green-100 text-green-800"
                          : product.status === "sold"
                            ? "bg-gray-100 text-gray-800"
                            : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {product.status === "active" ? "在售中" : product.status === "sold" ? "已售出" : "已隐藏"}
                    </span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => toggleVisibility(product.id)}
                        className="p-1 text-gray-500 hover:text-primary rounded-full hover:bg-gray-100"
                        aria-label={product.status === "hidden" ? "显示商品" : "隐藏商品"}
                      >
                        {product.status === "hidden" ? <Eye className="h-5 w-5" /> : <EyeOff className="h-5 w-5" />}
                      </button>
                      <Link
                        href={`/publish?edit=${product.id}`}
                        className="p-1 text-gray-500 hover:text-primary rounded-full hover:bg-gray-100"
                        aria-label="编辑商品"
                      >
                        <Edit className="h-5 w-5" />
                      </Link>
                      <button
                        onClick={() => deleteProduct(product.id)}
                        className="p-1 text-gray-500 hover:text-red-500 rounded-full hover:bg-gray-100"
                        aria-label="删除商品"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-500">
                没有
                {activeTab === "all" ? "" : activeTab === "active" ? "在售" : activeTab === "sold" ? "已售出" : "隐藏"}
                商品
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
