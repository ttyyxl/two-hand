"use client"

import { useState } from "react"
import { ShoppingBag, Menu, X, LogIn, ShoppingCart } from "lucide-react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useUser } from "../contexts/user-context"

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  // Initialize user context values with defaults
  let isLoggedIn = false
  let cartItems: any[] = []
  let logout = () => {}

  // Call useUser hook unconditionally
  try {
    const userContext = useUser()
    isLoggedIn = userContext?.isLoggedIn || false
    cartItems = userContext?.cartItems || []
    logout = userContext?.logout || (() => {})
  } catch (error) {
    console.error("UserContext not available:", error)
    // Fallback values are already set, continue with defaults
  }

  // Function to check if a link is active
  const isActive = (path: string) => pathname === path

  // Function to handle logout
  const handleLogout = () => {
    logout()
    closeMenu()
    router.push("/")
  }

  // Function to close mobile menu
  const closeMenu = () => setIsMenuOpen(false)

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <ShoppingBag className="h-8 w-8 text-primary-foreground" />
            <span className="text-xl font-bold text-primary-foreground">校园二手交易</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link
              href="/"
              className={`text-primary-foreground hover:text-white font-medium ${isActive("/") ? "underline underline-offset-4" : ""}`}
            >
              首页
            </Link>
            <Link
              href="/publish"
              className={`text-primary-foreground hover:text-white font-medium ${isActive("/publish") ? "underline underline-offset-4" : ""}`}
            >
              发布商品
            </Link>
            <Link
              href="/profile"
              className={`text-primary-foreground hover:text-white font-medium ${isActive("/profile") ? "underline underline-offset-4" : ""}`}
            >
              个人中心
            </Link>
            <Link
              href="/cart"
              className={`text-primary-foreground hover:text-white font-medium flex items-center ${isActive("/cart") ? "underline underline-offset-4" : ""}`}
            >
              <ShoppingCart className="h-5 w-5 mr-1" />
              购物车
              {cartItems.length > 0 && (
                <span className="ml-1 bg-white text-primary text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </Link>

            {isLoggedIn ? (
              <button
                onClick={handleLogout}
                className="text-primary-foreground hover:text-white font-medium flex items-center"
              >
                <LogIn className="h-5 w-5 mr-1 rotate-180" />
                退出
              </button>
            ) : (
              <Link
                href="/login"
                className={`text-primary-foreground hover:text-white font-medium flex items-center ${isActive("/login") ? "underline underline-offset-4" : ""}`}
              >
                <LogIn className="h-5 w-5 mr-1" />
                登录
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-primary-foreground"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "关闭菜单" : "打开菜单"}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-3 pb-3 space-y-3">
            <Link
              href="/"
              className={`block text-primary-foreground hover:text-white font-medium ${isActive("/") ? "underline underline-offset-4" : ""}`}
              onClick={closeMenu}
            >
              首页
            </Link>
            <Link
              href="/publish"
              className={`block text-primary-foreground hover:text-white font-medium ${isActive("/publish") ? "underline underline-offset-4" : ""}`}
              onClick={closeMenu}
            >
              发布商品
            </Link>
            <Link
              href="/profile"
              className={`block text-primary-foreground hover:text-white font-medium ${isActive("/profile") ? "underline underline-offset-4" : ""}`}
              onClick={closeMenu}
            >
              个人中心
            </Link>
            <Link
              href="/cart"
              className={`block text-primary-foreground hover:text-white font-medium flex items-center ${isActive("/cart") ? "underline underline-offset-4" : ""}`}
              onClick={closeMenu}
            >
              <ShoppingCart className="h-5 w-5 mr-1" />
              购物车
              {cartItems.length > 0 && (
                <span className="ml-1 bg-white text-primary text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </Link>

            {isLoggedIn ? (
              <button
                onClick={handleLogout}
                className="block text-primary-foreground hover:text-white font-medium flex items-center"
              >
                <LogIn className="h-5 w-5 mr-1 rotate-180" />
                退出
              </button>
            ) : (
              <Link
                href="/login"
                className={`block text-primary-foreground hover:text-white font-medium flex items-center ${isActive("/login") ? "underline underline-offset-4" : ""}`}
                onClick={closeMenu}
              >
                <LogIn className="h-5 w-5 mr-1" />
                登录
              </Link>
            )}
          </nav>
        )}
      </div>
    </header>
  )
}
