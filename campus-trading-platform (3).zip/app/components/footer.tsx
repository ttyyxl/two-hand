export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-6">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <p className="mb-2">© {new Date().getFullYear()} 校园二手交易平台 版权所有</p>
          <p className="text-gray-400 text-sm">本平台仅供校内学生使用，请遵守交易规则</p>
        </div>
      </div>
    </footer>
  )
}
