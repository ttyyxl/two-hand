"use client"

import type React from "react"

import { useState } from "react"
import { Phone, BadgeIcon as IdCard } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Navigation from "../components/navigation"
import Footer from "../components/footer"

export default function ForgotPasswordPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    phone: "",
    studentId: "",
    verificationCode: "",
  })

  const [errors, setErrors] = useState({
    phone: "",
    studentId: "",
    verificationCode: "",
    general: "",
  })

  const [isLoading, setIsLoading] = useState(false)
  const [codeSent, setCodeSent] = useState(false)
  const [countdown, setCountdown] = useState(0)

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    // Clear error when user types
    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }))
    }
  }

  // Validate form for sending code
  const validateSendCodeForm = () => {
    let isValid = true
    const newErrors = {
      phone: "",
      studentId: "",
      verificationCode: "",
      general: "",
    }

    // Validate phone (Chinese mobile number)
    const phoneRegex = /^1[3-9]\d{9}$/
    if (!formData.phone) {
      newErrors.phone = "请输入手机号"
      isValid = false
    } else if (!phoneRegex.test(formData.phone)) {
      newErrors.phone = "请输入有效的手机号"
      isValid = false
    }

    // Validate student ID (assuming a format like 20210001)
    const studentIdRegex = /^\d{8}$/
    if (!formData.studentId) {
      newErrors.studentId = "请输入学号"
      isValid = false
    } else if (!studentIdRegex.test(formData.studentId)) {
      newErrors.studentId = "学号格式不正确（8位数字）"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  // Validate form for resetting password
  const validateResetForm = () => {
    let isValid = true
    const newErrors = {
      phone: "",
      studentId: "",
      verificationCode: "",
      general: "",
    }

    // Validate verification code
    if (!formData.verificationCode) {
      newErrors.verificationCode = "请输入验证码"
      isValid = false
    } else if (formData.verificationCode.length !== 6) {
      newErrors.verificationCode = "验证码应为6位数字"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  // Handle sending verification code
  const handleSendCode = async () => {
    if (!validateSendCodeForm()) {
      return
    }

    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // In a real app, you would make an API call to your backend
      // const response = await fetch('/api/send-verification-code', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ phone: formData.phone, studentId: formData.studentId })
      // })

      // if (!response.ok) {
      //   throw new Error('Failed to send verification code')
      // }

      setCodeSent(true)
      setCountdown(60)

      // Start countdown
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer)
            return 0
          }
          return prev - 1
        })
      }, 1000)
    } catch (error) {
      setErrors((prev) => ({
        ...prev,
        general: "发送验证码失败，请稍后再试",
      }))
    } finally {
      setIsLoading(false)
    }
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateResetForm()) {
      return
    }

    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // In a real app, you would make an API call to your backend
      // const response = await fetch('/api/reset-password', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(formData)
      // })

      // if (!response.ok) {
      //   throw new Error('Password reset failed')
      // }

      // For demo purposes, we'll just redirect to the reset success page
      router.push("/reset-success")
    } catch (error) {
      setErrors((prev) => ({
        ...prev,
        general: "重置密码失败，请检查验证码是否正确",
      }))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Navigation />

      <main className="flex-grow container mx-auto px-4 py-8 flex items-center justify-center">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6 sm:p-8">
              <h1 className="text-2xl font-bold text-gray-800 mb-6 text-center">找回密码</h1>

              {errors.general && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
                  {errors.general}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="space-y-5">
                  {/* Phone Number */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      手机号
                    </label>
                    <div className="relative">
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        disabled={codeSent}
                        className={`w-full pl-10 pr-4 py-2 border ${
                          errors.phone ? "border-red-500" : "border-gray-300"
                        } rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent ${
                          codeSent ? "bg-gray-100" : ""
                        }`}
                        placeholder="请输入手机号"
                      />
                      <Phone className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                    </div>
                    {errors.phone && <p className="mt-1 text-sm text-red-600">{errors.phone}</p>}
                  </div>

                  {/* Student ID */}
                  <div>
                    <label htmlFor="studentId" className="block text-sm font-medium text-gray-700 mb-1">
                      学号
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        id="studentId"
                        name="studentId"
                        value={formData.studentId}
                        onChange={handleChange}
                        disabled={codeSent}
                        className={`w-full pl-10 pr-4 py-2 border ${
                          errors.studentId ? "border-red-500" : "border-gray-300"
                        } rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent ${
                          codeSent ? "bg-gray-100" : ""
                        }`}
                        placeholder="请输入学号"
                      />
                      <IdCard className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                    </div>
                    {errors.studentId && <p className="mt-1 text-sm text-red-600">{errors.studentId}</p>}
                  </div>

                  {/* Verification Code */}
                  <div>
                    <label htmlFor="verificationCode" className="block text-sm font-medium text-gray-700 mb-1">
                      验证码
                    </label>
                    <div className="flex space-x-2">
                      <div className="relative flex-grow">
                        <input
                          type="text"
                          id="verificationCode"
                          name="verificationCode"
                          value={formData.verificationCode}
                          onChange={handleChange}
                          className={`w-full px-3 py-2 border ${
                            errors.verificationCode ? "border-red-500" : "border-gray-300"
                          } rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent`}
                          placeholder="请输入验证码"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleSendCode}
                        disabled={isLoading || countdown > 0 || codeSent}
                        className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                      >
                        {countdown > 0 ? `${countdown}秒后重发` : "获取验证码"}
                      </button>
                    </div>
                    {errors.verificationCode && <p className="mt-1 text-sm text-red-600">{errors.verificationCode}</p>}
                  </div>

                  {/* Submit Button */}
                  <div>
                    <button
                      type="submit"
                      disabled={isLoading || !codeSent}
                      className="w-full px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isLoading ? "提交中..." : "下一步"}
                    </button>
                  </div>

                  {/* Login Link */}
                  <div className="text-center mt-4">
                    <p className="text-sm text-gray-600">
                      记起密码了?{" "}
                      <Link href="/login" className="text-primary hover:underline">
                        返回登录
                      </Link>
                    </p>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
