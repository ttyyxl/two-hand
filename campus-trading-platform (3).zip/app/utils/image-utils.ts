/**
 * 获取图片URL，如果没有图片则返回默认图片
 * @param imageUrl 图片URL
 * @param type 图片类型（product, avatar, 等）
 * @param title 商品标题（用于生成相关的默认图片）
 * @param category 商品分类（用于生成相关的默认图片）
 * @returns 有效的图片URL
 */
export function getImageUrl(
  imageUrl?: string,
  type: "product" | "avatar" = "product",
  title?: string,
  category?: string,
): string {
  // 检查图片URL是否有效（不为空且不是占位符）
  if (imageUrl && imageUrl.trim() !== "" && !imageUrl.includes("placeholder.svg")) {
    return imageUrl
  }

  // 根据类型返回不同的默认图片
  switch (type) {
    case "avatar":
      return "/placeholder.svg?height=200&width=200&text=👤"
    case "product":
      // 如果有标题或分类，根据它们选择合适的默认图片
      if (title || category) {
        return getProductImageByTitleOrCategory(title || "", category || "")
      }
      return "/placeholder.svg?height=300&width=400&text=📦"
    default:
      return "/placeholder.svg?height=300&width=400&text=📦"
  }
}

/**
 * 根据商品标题或分类选择合适的默认图片
 * @param title 商品标题
 * @param category 商品分类
 * @returns 默认图片URL
 */
function getProductImageByTitleOrCategory(title: string, category: string): string {
  const lowerTitle = title.toLowerCase()
  const lowerCategory = category.toLowerCase()

  // 首先检查分类
  if (lowerCategory.includes("电子产品") || lowerCategory.includes("electronic")) {
    return "/placeholder.svg?height=300&width=400&text=💻"
  }
  if (lowerCategory.includes("书籍") || lowerCategory.includes("教材") || lowerCategory.includes("book")) {
    return "/placeholder.svg?height=300&width=400&text=📚"
  }
  if (lowerCategory.includes("家居") || lowerCategory.includes("furniture")) {
    return "/placeholder.svg?height=300&width=400&text=🪑"
  }
  if (lowerCategory.includes("服装") || lowerCategory.includes("鞋帽") || lowerCategory.includes("clothing")) {
    return "/placeholder.svg?height=300&width=400&text=👕"
  }
  if (lowerCategory.includes("运动") || lowerCategory.includes("sports")) {
    return "/placeholder.svg?height=300&width=400&text=🏀"
  }
  if (lowerCategory.includes("乐器") || lowerCategory.includes("instrument")) {
    return "/placeholder.svg?height=300&width=400&text=🎸"
  }
  if (lowerCategory.includes("自行车") || lowerCategory.includes("bicycle")) {
    return "/placeholder.svg?height=300&width=400&text=🚲"
  }

  // 然后检查标题
  // 电子产品
  if (lowerTitle.includes("电脑") || lowerTitle.includes("笔记本") || lowerTitle.includes("laptop")) {
    return "/placeholder.svg?height=300&width=400&text=💻"
  }
  if (lowerTitle.includes("手机") || lowerTitle.includes("phone")) {
    return "/placeholder.svg?height=300&width=400&text=📱"
  }
  if (lowerTitle.includes("平板") || lowerTitle.includes("ipad") || lowerTitle.includes("tablet")) {
    return "/placeholder.svg?height=300&width=400&text=📱"
  }
  if (lowerTitle.includes("相机") || lowerTitle.includes("camera")) {
    return "/placeholder.svg?height=300&width=400&text=📷"
  }
  if (lowerTitle.includes("耳机") || lowerTitle.includes("headphone")) {
    return "/placeholder.svg?height=300&width=400&text=🎧"
  }
  if (lowerTitle.includes("音响") || lowerTitle.includes("speaker")) {
    return "/placeholder.svg?height=300&width=400&text=🔊"
  }
  if (lowerTitle.includes("显示器") || lowerTitle.includes("monitor")) {
    return "/placeholder.svg?height=300&width=400&text=🖥️"
  }

  // 交通工具
  if (lowerTitle.includes("自行车") || lowerTitle.includes("单车") || lowerTitle.includes("bike")) {
    return "/placeholder.svg?height=300&width=400&text=🚲"
  }
  if (lowerTitle.includes("滑板") || lowerTitle.includes("skateboard")) {
    return "/placeholder.svg?height=300&width=400&text=🛹"
  }

  // 书籍和学习用品
  if (lowerTitle.includes("书") || lowerTitle.includes("教材") || lowerTitle.includes("book")) {
    return "/placeholder.svg?height=300&width=400&text=📚"
  }
  if (lowerTitle.includes("笔") || lowerTitle.includes("pen")) {
    return "/placeholder.svg?height=300&width=400&text=✏️"
  }

  // 运动用品
  if (lowerTitle.includes("篮球") || lowerTitle.includes("basketball")) {
    return "/placeholder.svg?height=300&width=400&text=🏀"
  }
  if (lowerTitle.includes("足球") || lowerTitle.includes("soccer") || lowerTitle.includes("football")) {
    return "/placeholder.svg?height=300&width=400&text=⚽"
  }
  if (lowerTitle.includes("网球") || lowerTitle.includes("tennis")) {
    return "/placeholder.svg?height=300&width=400&text=🎾"
  }
  if (lowerTitle.includes("乒乓") || lowerTitle.includes("ping pong")) {
    return "/placeholder.svg?height=300&width=400&text=🏓"
  }

  // 乐器
  if (lowerTitle.includes("吉他") || lowerTitle.includes("guitar")) {
    return "/placeholder.svg?height=300&width=400&text=🎸"
  }
  if (lowerTitle.includes("钢琴") || lowerTitle.includes("piano")) {
    return "/placeholder.svg?height=300&width=400&text=🎹"
  }
  if (lowerTitle.includes("鼓") || lowerTitle.includes("drum")) {
    return "/placeholder.svg?height=300&width=400&text=🥁"
  }

  // 家居用品
  if (lowerTitle.includes("桌") || lowerTitle.includes("table")) {
    return "/placeholder.svg?height=300&width=400&text=🪑"
  }
  if (lowerTitle.includes("椅") || lowerTitle.includes("chair")) {
    return "/placeholder.svg?height=300&width=400&text=🪑"
  }
  if (lowerTitle.includes("床") || lowerTitle.includes("bed")) {
    return "/placeholder.svg?height=300&width=400&text=🛏️"
  }
  if (lowerTitle.includes("灯") || lowerTitle.includes("light")) {
    return "/placeholder.svg?height=300&width=400&text=💡"
  }
  if (lowerTitle.includes("柜") || lowerTitle.includes("cabinet")) {
    return "/placeholder.svg?height=300&width=400&text=🗄️"
  }

  // 默认图片
  return "/placeholder.svg?height=300&width=400&text=📦"
}
