"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// 用户信息类型
export interface UserProfile {
  id: string
  name: string
  birthday: string
  gender: string
  address: string
  avatar: string
}

// 购物车商品类型
export interface CartItem {
  id: number
  title: string
  price: number
  image: string
  seller: string
}

// 用户发布的商品类型
export interface UserProduct {
  id: number
  title: string
  price: number
  image: string
  status: "active" | "sold" | "hidden"
  views: number
  createdAt: string
}

// 用户上下文类型
interface UserContextType {
  isLoggedIn: boolean
  currentUser: UserProfile | null
  cartItems: CartItem[]
  userProducts: UserProduct[]
  login: (userId: string, password: string) => Promise<boolean>
  logout: () => void
  updateProfile: (profile: Partial<UserProfile>) => void
  addToCart: (item: CartItem) => void
  removeFromCart: (itemId: number) => void
  clearCart: () => void
  updateUserProduct: (product: UserProduct) => void
  removeUserProduct: (productId: number) => void
}

// 默认用户数据
const defaultUsers: Record<string, { profile: UserProfile; password: string }> = {
  user123: {
    profile: {
      id: "user123",
      name: "张同学",
      birthday: "2000-01-01",
      gender: "male",
      address: "东区宿舍3栋",
      avatar: "/placeholder.svg?height=200&width=200",
    },
    password: "password123",
  },
  user456: {
    profile: {
      id: "user456",
      name: "李同学",
      birthday: "2001-05-15",
      gender: "female",
      address: "西区宿舍2栋",
      avatar: "/placeholder.svg?height=200&width=200",
    },
    password: "password456",
  },
}

// 默认商品数据
const defaultUserProducts: Record<string, UserProduct[]> = {
  user123: [
    {
      id: 101,
      title: "二手课本",
      price: 30,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
      views: 15,
      createdAt: "2024-03-15",
    },
    {
      id: 102,
      title: "自行车",
      price: 350,
      image: "/placeholder.svg?height=200&width=300",
      status: "sold",
      views: 42,
      createdAt: "2024-03-10",
    },
  ],
  user456: [
    {
      id: 103,
      title: "台灯",
      price: 45,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
      views: 8,
      createdAt: "2024-03-05",
    },
  ],
}

// 创建上下文
const UserContext = createContext<UserContextType | undefined>(undefined)

// 创建默认上下文值
export const defaultUserContext: UserContextType = {
  isLoggedIn: false,
  currentUser: null,
  cartItems: [],
  userProducts: [],
  login: async () => false,
  logout: () => {},
  updateProfile: () => {},
  addToCart: () => {},
  removeFromCart: () => {},
  clearCart: () => {},
  updateUserProduct: () => {},
  removeUserProduct: () => {},
}

// 上下文提供者组件
export function UserProvider({ children }: { children: ReactNode }) {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false)
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null)
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [userProducts, setUserProducts] = useState<UserProduct[]>([])

  // 从本地存储加载用户数据
  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        const storedUser = localStorage.getItem("currentUser")
        const storedCart = localStorage.getItem("cartItems")
        const storedProducts = localStorage.getItem("userProducts")

        if (storedUser) {
          const userData = JSON.parse(storedUser)
          setCurrentUser(userData)
          setIsLoggedIn(true)
        }

        if (storedCart) {
          setCartItems(JSON.parse(storedCart))
        }

        if (storedProducts) {
          setUserProducts(JSON.parse(storedProducts))
        }
      } catch (error) {
        console.error("Error loading user data from localStorage:", error)
      }
    }
  }, [])

  // 保存数据到本地存储
  useEffect(() => {
    if (typeof window !== "undefined" && isLoggedIn && currentUser) {
      try {
        localStorage.setItem("currentUser", JSON.stringify(currentUser))
        localStorage.setItem("cartItems", JSON.stringify(cartItems))
        localStorage.setItem("userProducts", JSON.stringify(userProducts))
      } catch (error) {
        console.error("Error saving user data to localStorage:", error)
      }
    }
  }, [isLoggedIn, currentUser, cartItems, userProducts])

  // 登录函数
  const login = async (userId: string, password: string): Promise<boolean> => {
    // 模拟API调用
    await new Promise((resolve) => setTimeout(resolve, 500))

    const user = defaultUsers[userId]
    if (user && user.password === password) {
      setCurrentUser(user.profile)
      setIsLoggedIn(true)

      // 加载该用户的商品数据
      setUserProducts(defaultUserProducts[userId] || [])

      // 清空购物车（新用户登录）
      setCartItems([])

      return true
    }
    return false
  }

  // 退出登录函数
  const logout = () => {
    // 保存当前用户数据到本地存储（已在useEffect中处理）

    // 清除当前用户状态
    setIsLoggedIn(false)
    setCurrentUser(null)

    // 不清除购物车和用户商品数据，因为我们希望在退出登录后保留这些数据
  }

  // 更新用户资料
  const updateProfile = (profile: Partial<UserProfile>) => {
    if (currentUser) {
      const updatedProfile = { ...currentUser, ...profile }
      setCurrentUser(updatedProfile)
    }
  }

  // 添加商品到购物车
  const addToCart = (item: CartItem) => {
    // 检查商品是否已在购物车中
    const exists = cartItems.some((cartItem) => cartItem.id === item.id)
    if (!exists) {
      setCartItems([...cartItems, item])
    }
  }

  // 从购物车移除商品
  const removeFromCart = (itemId: number) => {
    setCartItems(cartItems.filter((item) => item.id !== itemId))
  }

  // 清空购物车
  const clearCart = () => {
    setCartItems([])
  }

  // 更新用户商品
  const updateUserProduct = (product: UserProduct) => {
    setUserProducts((prevProducts) => prevProducts.map((p) => (p.id === product.id ? product : p)))
  }

  // 移除用户商品
  const removeUserProduct = (productId: number) => {
    setUserProducts((prevProducts) => prevProducts.filter((p) => p.id !== productId))
  }

  return (
    <UserContext.Provider
      value={{
        isLoggedIn,
        currentUser,
        cartItems,
        userProducts,
        login,
        logout,
        updateProfile,
        addToCart,
        removeFromCart,
        clearCart,
        updateUserProduct,
        removeUserProduct,
      }}
    >
      {children}
    </UserContext.Provider>
  )
}

// 自定义钩子，用于访问上下文
export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}
