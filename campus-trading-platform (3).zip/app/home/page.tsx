"use client"

import { useState, useEffect } from "react"
import { Search } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { getImageUrl } from "../utils/image-utils"

// 初始商品数据
const initialProducts = [
  {
    id: 1,
    title: "二手笔记本电脑",
    price: 2500,
    location: "东区宿舍",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=500&auto=format&fit=crop",
    category: "电子产品",
    description: "戴尔笔记本电脑，i5处理器，8GB内存，256GB固态硬盘，使用了2年，成色9成新，无明显磨损。",
    seller: {
      id: "user123",
      name: "张同学",
      avatar: "",
    },
  },
  {
    id: 2,
    title: "自行车",
    price: 350,
    location: "西区宿舍",
    image: "https://images.unsplash.com/photo-1485965120184-e220f721d03e?q=80&w=500&auto=format&fit=crop",
    category: "自行车",
    description: "捷安特自行车，使用一年，外观良好，轮胎完好，适合校园通勤。",
    seller: {
      id: "user456",
      name: "李同学",
      avatar: "",
    },
  },
  {
    id: 3,
    title: "考研教材全套",
    price: 120,
    location: "图书馆",
    image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=500&auto=format&fit=crop",
    category: "书籍教材",
    description: "包含数学、英语、政治全套教材和辅导资料，有少量笔记，保存完好。",
    seller: {
      id: "user789",
      name: "王同学",
      avatar: "",
    },
  },
  {
    id: 4,
    title: "篮球",
    price: 80,
    location: "体育馆",
    image: "https://images.unsplash.com/photo-1608245449230-4ac19066d2d0?q=80&w=500&auto=format&fit=crop",
    category: "运动器材",
    description: "斯伯丁篮球，使用3个月，手感良好，适合室内外使用。",
    seller: {
      id: "user101",
      name: "赵同学",
      avatar: "",
    },
  },
  {
    id: 5,
    title: "吉他",
    price: 450,
    location: "音乐学院",
    image: "https://images.unsplash.com/photo-1525201548942-d8732f6617a0?q=80&w=500&auto=format&fit=crop",
    category: "乐器",
    description: "雅马哈吉他，F310型号，木吉他，音色清脆，适合初学者。",
    seller: {
      id: "user121",
      name: "钱同学",
      avatar: "",
    },
  },
  {
    id: 6,
    title: "显示器",
    price: 600,
    location: "计算机学院",
    image: "https://images.unsplash.com/photo-1586210579191-33b45e38fa2c?q=80&w=500&auto=format&fit=crop",
    category: "电子产品",
    description: "AOC 24英寸显示器，1080p分辨率，75Hz刷新率，使用半年，无坏点。",
    seller: {
      id: "user123",
      name: "张同学",
      avatar: "",
    },
  },
  {
    id: 7,
    title: "床头柜",
    price: 150,
    location: "南区宿舍",
    image: "https://images.unsplash.com/photo-1595428774223-ef52624120d2?q=80&w=500&auto=format&fit=crop",
    category: "家居用品",
    description: "宜家床头柜，两层抽屉，白色，使用一年，状态良好。",
    seller: {
      id: "user456",
      name: "李同学",
      avatar: "",
    },
  },
  {
    id: 8,
    title: "台灯",
    price: 45,
    location: "北区宿舍",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=500&auto=format&fit=crop",
    category: "家居用品",
    description: "LED护眼台灯，三档亮度调节，USB充电，几乎全新。",
    seller: {
      id: "user789",
      name: "王同学",
      avatar: "",
    },
  },
]

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [priceRange, setPriceRange] = useState({ min: "", max: "" })
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  // 从本地存储加载新发布的商品
  useEffect(() => {
    // 首先加载初始商品
    setProducts(initialProducts)
    setLoading(true)

    // 然后加载用户发布的商品
    try {
      const storedProducts = localStorage.getItem("publishedProducts")
      if (storedProducts) {
        const parsedProducts = JSON.parse(storedProducts)
        if (Array.isArray(parsedProducts) && parsedProducts.length > 0) {
          // 将新发布的商品放在前面，以便它们首先显示
          setProducts((prevProducts) => [...parsedProducts, ...prevProducts])
        }
      }
    } catch (error) {
      console.error("Failed to parse stored products:", error)
    } finally {
      setLoading(false)
    }
  }, [])

  // Filter products based on search query and price range
  const filteredProducts = products.filter((product) => {
    const matchesQuery =
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.location.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesPrice =
      (priceRange.min === "" || product.price >= Number(priceRange.min)) &&
      (priceRange.max === "" || product.price <= Number(priceRange.max))

    return matchesQuery && matchesPrice
  })

  return (
    <main className="flex-grow container mx-auto px-4 py-8">
      {/* Search Section */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-8">
        <div className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-grow">
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              搜索商品
            </label>
            <div className="relative">
              <input
                type="text"
                id="search"
                placeholder="输入关键词..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>

          <div className="flex space-x-4">
            <div>
              <label htmlFor="min-price" className="block text-sm font-medium text-gray-700 mb-1">
                最低价格
              </label>
              <input
                type="number"
                id="min-price"
                placeholder="¥"
                className="w-24 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                value={priceRange.min}
                onChange={(e) => setPriceRange({ ...priceRange, min: e.target.value })}
              />
            </div>

            <div>
              <label htmlFor="max-price" className="block text-sm font-medium text-gray-700 mb-1">
                最高价格
              </label>
              <input
                type="number"
                id="max-price"
                placeholder="¥"
                className="w-24 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                value={priceRange.max}
                onChange={(e) => setPriceRange({ ...priceRange, max: e.target.value })}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="text-center py-8">
          <p className="text-gray-500">加载商品中...</p>
        </div>
      )}

      {/* Products Grid */}
      {!loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <Link
                href={`/product/${product.id}`}
                key={product.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 block"
              >
                <div className="relative h-48">
                  <Image
                    src={
                      product.images && product.images.length > 0
                        ? product.images[0]
                        : product.image || getImageUrl("", "product", product.title, product.category)
                    }
                    alt={product.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2 truncate">{product.title}</h3>
                  <p className="text-primary font-bold text-xl mb-2">¥{product.price}</p>
                  <div className="flex items-center text-gray-500 text-sm">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                    {product.location}
                  </div>
                </div>
              </Link>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500 text-lg">没有找到符合条件的商品</p>
            </div>
          )}
        </div>
      )}
    </main>
  )
}
