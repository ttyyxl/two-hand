"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Upload, MapPin, Tag, FileText } from "lucide-react"
import Image from "next/image"
import { useRouter, useSearchParams } from "next/navigation"
import Navigation from "../components/navigation"
import Footer from "../components/footer"
import { useUser } from "../contexts/user-context"

export default function PublishPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const editId = searchParams.get("edit")
  const { currentUser } = useUser()

  const [product, setProduct] = useState({
    title: "",
    price: "",
    location: "",
    category: "",
    description: "",
    images: [] as string[],
  })

  const [previewImages, setPreviewImages] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  // 如果是编辑模式，尝试从本地存储加载商品数据
  useEffect(() => {
    if (editId) {
      try {
        const storedProducts = localStorage.getItem("publishedProducts")
        if (storedProducts) {
          const parsedProducts = JSON.parse(storedProducts)
          const productToEdit = parsedProducts.find((p: any) => p.id === Number(editId))

          if (productToEdit) {
            setProduct({
              title: productToEdit.title || "",
              price: String(productToEdit.price) || "",
              location: productToEdit.location || "",
              category: productToEdit.category || "",
              description: productToEdit.description || "",
              images: productToEdit.images || [],
            })

            setPreviewImages(productToEdit.images && productToEdit.images.length > 0 ? productToEdit.images : [])
          }
        }
      } catch (error) {
        console.error("Failed to parse stored products:", error)
        setError("加载商品数据失败，请重试")
      }
    }
  }, [editId])

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProduct((prev) => ({ ...prev, [name]: value }))
  }

  // Handle image upload
  const handleImageClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      const newPreviewImages = [...previewImages]

      Array.from(files).forEach((file) => {
        // 检查文件大小 (限制为5MB)
        if (file.size > 5 * 1024 * 1024) {
          setError("图片大小不能超过5MB")
          return
        }

        const reader = new FileReader()
        reader.onloadend = () => {
          if (newPreviewImages.length < 5) {
            // Limit to 5 images
            newPreviewImages.push(reader.result as string)
            setPreviewImages([...newPreviewImages])
          }
        }
        reader.onerror = () => {
          setError("读取图片失败，请重试")
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const removeImage = (index: number) => {
    const newImages = [...previewImages]
    newImages.splice(index, 1)
    setPreviewImages(newImages)
  }

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)

    try {
      // 基本验证
      if (!product.title.trim()) {
        throw new Error("请输入商品标题")
      }

      if (!product.price || isNaN(Number(product.price)) || Number(product.price) <= 0) {
        throw new Error("请输入有效的价格")
      }

      if (!product.category) {
        throw new Error("请选择商品分类")
      }

      if (!product.location.trim()) {
        throw new Error("请输入交易地点")
      }

      if (!product.description.trim()) {
        throw new Error("请输入商品描述")
      }

      // 创建新商品对象
      const newProduct = {
        id: editId ? Number(editId) : Date.now(), // 使用时间戳作为ID或保留原ID
        title: product.title.trim(),
        price: Number(product.price),
        location: product.location.trim(),
        category: product.category,
        description: product.description.trim(),
        images: previewImages,
        createdAt: new Date().toISOString().split("T")[0], // 当前日期
        status: "active",
        views: 0,
        seller: {
          id: currentUser?.id || "current_user",
          name: currentUser?.name || "当前用户",
          avatar: currentUser?.avatar || "",
        },
      }

      // 保存到本地存储
      let products = []

      try {
        const storedProducts = localStorage.getItem("publishedProducts")
        if (storedProducts) {
          products = JSON.parse(storedProducts)
        }
      } catch (error) {
        console.error("Failed to parse stored products:", error)
        products = []
      }

      // 确保products是数组
      if (!Array.isArray(products)) {
        products = []
      }

      if (editId) {
        // 如果是编辑模式，更新现有商品
        const index = products.findIndex((p: any) => p.id === Number(editId))
        if (index !== -1) {
          products[index] = newProduct
        } else {
          products.push(newProduct)
        }
      } else {
        // 如果是新增模式，添加新商品
        products.push(newProduct)
      }

      // 保存到localStorage
      localStorage.setItem("publishedProducts", JSON.stringify(products))

      // 显示成功消息
      alert(editId ? "商品已更新！" : "商品已发布！")

      // 重置表单或跳转到首页
      if (!editId) {
        setProduct({
          title: "",
          price: "",
          location: "",
          category: "",
          description: "",
          images: [],
        })
        setPreviewImages([])

        // 跳转到首页查看新发布的商品
        router.push("/")
      } else {
        router.push("/profile") // 编辑完成后返回个人中心
      }
    } catch (error: any) {
      console.error("Error in handleSubmit:", error)
      setError(error.message || "发布商品时出错，请重试")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Categories
  const categories = ["电子产品", "书籍教材", "家居用品", "服装鞋帽", "运动器材", "乐器", "自行车", "其他"]

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Navigation />

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 sm:p-8">
            <h1 className="text-2xl font-bold text-gray-800 mb-6">{editId ? "编辑商品" : "发布二手商品"}</h1>

            {error && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">{error}</div>
            )}

            <form onSubmit={handleSubmit}>
              <div className="space-y-6">
                {/* Product Images */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">商品图片 (最多5张)</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {previewImages.length > 0 ? (
                      // 显示用户上传的图片
                      previewImages.map((image, index) => (
                        <div key={index} className="relative h-32 bg-gray-100 rounded-md overflow-hidden">
                          <Image
                            src={image || "/placeholder.svg"}
                            alt={`Product image ${index + 1}`}
                            fill
                            className="object-cover"
                          />
                          <button
                            type="button"
                            className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center"
                            onClick={() => removeImage(index)}
                          >
                            ×
                          </button>
                        </div>
                      ))
                    ) : (
                      // 显示上传图片的提示
                      <div
                        className="h-32 col-span-full border-2 border-dashed border-gray-300 rounded-md flex flex-col items-center justify-center cursor-pointer"
                        onClick={handleImageClick}
                      >
                        <Upload className="h-8 w-8 text-gray-400 mb-2" />
                        <p className="text-sm text-gray-500">点击上传商品图片</p>
                      </div>
                    )}

                    {previewImages.length > 0 && previewImages.length < 5 && (
                      <div
                        className="h-32 border-2 border-dashed border-gray-300 rounded-md flex items-center justify-center cursor-pointer"
                        onClick={handleImageClick}
                      >
                        <Upload className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    accept="image/*"
                    multiple
                    onChange={handleFileChange}
                  />
                </div>

                {/* Product Title */}
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    商品标题
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={product.title}
                      onChange={handleChange}
                      required
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="请输入商品标题"
                    />
                    <Tag className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                {/* Price */}
                <div>
                  <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
                    价格 (元)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      id="price"
                      name="price"
                      value={product.price}
                      onChange={handleChange}
                      required
                      min="0"
                      step="0.01"
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="请输入价格"
                    />
                    <span className="absolute left-3 top-2.5 text-gray-400 font-medium">￥</span>
                  </div>
                </div>

                {/* Category */}
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                    分类
                  </label>
                  <select
                    id="category"
                    name="category"
                    value={product.category}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="" disabled>
                      请选择分类
                    </option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Location */}
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    交易地点
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      id="location"
                      name="location"
                      value={product.location}
                      onChange={handleChange}
                      required
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="请输入交易地点"
                    />
                    <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    商品描述
                  </label>
                  <div className="relative">
                    <textarea
                      id="description"
                      name="description"
                      value={product.description}
                      onChange={handleChange}
                      rows={4}
                      required
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      placeholder="请详细描述商品的成色、使用年限、功能等信息"
                    />
                    <FileText className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                </div>

                {/* Submit Button */}
                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? "提交中..." : editId ? "更新商品" : "发布商品"}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
