import Navigation from "./components/navigation"
import Footer from "./components/footer"
import HomePage from "./home/page"
import { UserProvider } from "./contexts/user-context"

export default function Home() {
  return (
    <UserProvider>
      <div className="flex flex-col min-h-screen bg-gray-50">
        <Navigation />
        <HomePage />
        <Footer />
      </div>
    </UserProvider>
  )
}
