"use client"

import { useState } from "react"
import { Search, ShoppingBag, Menu, X } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function CampusTradingPlatform() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [priceRange, setPriceRange] = useState({ min: "", max: "" })

  // Mock product data
  const products = [
    {
      id: 1,
      title: "二手笔记本电脑",
      price: 2500,
      location: "东区宿舍",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "自行车",
      price: 350,
      location: "西区宿舍",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 3,
      title: "考研教材全套",
      price: 120,
      location: "图书馆",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 4,
      title: "篮球",
      price: 80,
      location: "体育馆",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 5,
      title: "吉他",
      price: 450,
      location: "音乐学院",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 6,
      title: "显示器",
      price: 600,
      location: "计算机学院",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 7,
      title: "床头柜",
      price: 150,
      location: "南区宿舍",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 8,
      title: "台灯",
      price: 45,
      location: "北区宿舍",
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  // Filter products based on search query and price range
  const filteredProducts = products.filter((product) => {
    const matchesQuery =
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.location.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesPrice =
      (priceRange.min === "" || product.price >= Number(priceRange.min)) &&
      (priceRange.max === "" || product.price <= Number(priceRange.max))

    return matchesQuery && matchesPrice
  })

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <header className="bg-primary shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <ShoppingBag className="h-8 w-8 text-primary-foreground" />
              <span className="text-xl font-bold text-primary-foreground">校园二手交易</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className="text-primary-foreground hover:text-white font-medium">
                首页
              </Link>
              <Link href="/publish" className="text-primary-foreground hover:text-white font-medium">
                发布商品
              </Link>
              <Link href="/profile" className="text-primary-foreground hover:text-white font-medium">
                个人中心
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-primary-foreground" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <nav className="md:hidden mt-3 pb-3 space-y-3">
              <Link
                href="/"
                className="block text-primary-foreground hover:text-white font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                首页
              </Link>
              <Link
                href="/publish"
                className="block text-primary-foreground hover:text-white font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                发布商品
              </Link>
              <Link
                href="/profile"
                className="block text-primary-foreground hover:text-white font-medium"
                onClick={() => setIsMenuOpen(false)}
              >
                个人中心
              </Link>
            </nav>
          )}
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Search Section */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-8">
          <div className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-4">
            <div className="flex-grow">
              <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
                搜索商品
              </label>
              <div className="relative">
                <input
                  type="text"
                  id="search"
                  placeholder="输入关键词..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div className="flex space-x-4">
              <div>
                <label htmlFor="min-price" className="block text-sm font-medium text-gray-700 mb-1">
                  最低价格
                </label>
                <input
                  type="number"
                  id="min-price"
                  placeholder="¥"
                  className="w-24 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  value={priceRange.min}
                  onChange={(e) => setPriceRange({ ...priceRange, min: e.target.value })}
                />
              </div>

              <div>
                <label htmlFor="max-price" className="block text-sm font-medium text-gray-700 mb-1">
                  最高价格
                </label>
                <input
                  type="number"
                  id="max-price"
                  placeholder="¥"
                  className="w-24 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  value={priceRange.max}
                  onChange={(e) => setPriceRange({ ...priceRange, max: e.target.value })}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.length > 0 ? (
            filteredProducts.map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="relative h-48">
                  <Image src={product.image || "/placeholder.svg"} alt={product.title} fill className="object-cover" />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2 truncate">{product.title}</h3>
                  <p className="text-primary font-bold text-xl mb-2">¥{product.price}</p>
                  <div className="flex items-center text-gray-500 text-sm">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 mr-1"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                      />
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                      />
                    </svg>
                    {product.location}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500 text-lg">没有找到符合条件的商品</p>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p className="mb-2">© {new Date().getFullYear()} 校园二手交易平台 版权所有</p>
            <p className="text-gray-400 text-sm">本平台仅供校内学生使用，请遵守交易规则</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
